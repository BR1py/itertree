'''
helper classes used in DataTree object
'''
from __future__ import absolute_import
import time
import fnmatch
# We are testing here if numpy is available
try:
    import numpy as np
    try:
        np_object=np.object_
    except TypeError:
        np_object=np.object
except ImportError:
    np=None
np=None

#CONSTANTS used as parameters of methods in DataTree and related classes
#Filter constants
TEMPORARY=T=0b10
LINKED = L = 0b100
NORMAL= N = 0b1
ALL=T|L|N
#copy constants
COPY_OFF=0
COPY_NORMAL=1
COPY_DEEP=2
#match operation combine
AND=0
OR=1


class iTMagicList():
    '''
    This object should increase th performance on huge lists by allocating the memory in blocks
    and by using numpy (if available)
    '''
    __slots__ = ('_length','_items','_is_list')

    PRE_ALLOC_SIZE = 500

    def __init__(self, def_list=None):
        if def_list is not None:
            self._length = len(def_list)
            if self._length > self.PRE_ALLOC_SIZE:
                if np is None:
                    self._items = def_list
                else:
                    self._items = np.array(def_list, dtype=np_object)
                self._pre_alloc_list()
        else:
            self._length = 0
            self._items = []
        self._is_list = True

    def _pre_alloc_list(self,length=None):
        if length is None:
            length=self.PRE_ALLOC_SIZE
        else:
            length=length+self.PRE_ALLOC_SIZE
        if np is None:
            self._items = self._items.extend([0] * length)
            self._is_list = True
        else:
            self._items = np.hstack([self._items, np.empty(length, dtype=np_object)])
            self._is_list = False

    def __getitem__(self, key):
        if key < 0:
            key = self._length - key
        return self._items[:self._length][key]

    def __setitem__(self, key, item):
        if key < 0:
            key = self._length - key
        try:
            self._items[key] = item
            self._length += 1
        except IndexError:
            self._pre_alloc_list()
            self._items[key] = item
            self._length += 1

    def __delitem__(self, key):
        if self._is_list:
            if type(key) is int:
                del self._items[key]
            else:
                for k in key:
                    del self._items[key]
        else:
            if type(key) is int:
                key = [key]
            self._items = np.delete(self._items, key)

    def __length__(self):
        return self._length

    def __contains__(self,other):
        return other in self._items

    def __iter__(self):
        return iter(self._items)

    def remove(self, item):
        if self._is_list:
            self._items.remove(item)
        else:
            i = np.where(self._items == item)[0]
            if len(i) > 0:
                self._items = np.delete(self._items, i)

    def insert(self,key,item):
        if key<0:
            key=self._length-key
        if key>self._length:
            # we append
            try:
                self._items[self._length] = item
                self._length += 1
            except IndexError:
                self._pre_alloc_list()
                self._items[self._length] = item
                self._length += 1
        else:
            if self._is_list:
                self._items.insert(key,item)
                self._length += 1
            else:
                self._items=np.hstack([self._items[:self._length],[item],self._items[self._length:]])
                self._length += 1

    def append(self, item):
        try:
            self._items[self._length] = item
            self._length += 1
        except IndexError:
            self._pre_alloc_list()
            self._items[self._length] = item
            self._length += 1

    def extend(self, items):
        if self._is_list:
            self._items=self._items[:self._length]+list(items)+self._items[self._length:]
        else:
            if len(items) > (len(self._items) - self._length):
                self._pre_alloc_list(len(items))
            self._items[np.arange(len(items))]=np.array(items,dtype=np_object)

    def pop(self,key=None):
        if key is None:
            key=self._length-1
        item=self._item[key]
        if self._is_list:
            if type(key) is int:
                del self._items[key]
            else:
                for k in key:
                    del self._items[key]
        else:
            if type(key) is int:
                key = [key]
            self._items = np.delete(self._items, key)
        return item

class iTLink(object):
    '''
    Definition of a link to an element in another DataTree
    '''
    __slots__ = ("_ref_path", "_ref_key",'_loaded')

    def __init__(self, ref_path, ref_key, ref_first=False):
        self._ref_path = ref_path
        self._ref_key = ref_key
        self._loaded = None

    @property
    def loaded(self):
        return self._loaded

    @property
    def is_iTreeLink(self):
        return True

    def set_loaded(self):
        self._loaded=time.time()

    def dict_repr(self):
        return {'ref_path':self._ref_path,'ref_key':self._ref_key}

    def __repr__(self):
        return 'iTreeLink(ref_path=%s, ref_key=%s)' % (
        repr(self._ref_path), repr(self._ref_key), )


class iTMatch(object):
    '''
    The match object is used to defined match to elements in the DtaTree used in  iterations over the DataTree
    '''

    __slots__=('_pattern', '_op', '_check')

    def __init__(self, pattern, combine=OR):
        self._pattern = pattern
        self._op = combine
        self._check = self._analyse(pattern)

    @property
    def is_iTreeMatch(self):
        return True

    def _analyse(self, pattern):
        t = type(pattern)
        if t is int:
            return {self._check_idxs: [pattern]}
        elif t is slice:
            if self._op:
                # in case of or we will search in a set
                return {
                    self._check_idxs: {i for i in range(pattern._start, pattern.step, pattern.stop)}}
            else:
                # in case of and we have a list that will be checked
                # this is possible but makes no sense for the slice case
                # anyway we will deliver a result (mostly False)
                return {
                    self._check_idxs: {i for i in range(pattern.start, pattern.step, pattern.stop)}}
        elif t is TagIdx:
            check_dict={}
            tag=pattern[0]
            if type(tag) is str:
                check_dict[self._check_tag_str] = [tag]
            else:
                check_dict[self._check_tag_eq] = [tag]
            idx=pattern[1]
            t2=type(idx)
            if t2 is int:
                check_dict[self._check_idxs]= {idx}
            elif t2 is slice:
                check_dict[self._check_idxs]= {i for i in range(idx.start, idx.step, idx.stop)}
            else: #index list!
                check_dict[self._check_idxs] = idx

            return {
                self._check_idxs: {i for i in range(pattern._start, pattern.step, pattern.stop)}}
        elif t is str:
            return {self._check_tag_str: [pattern]}
        elif len(pattern) > 1:
            if self._op:
                return {self._check_sub: {i for i in pattern}}
            else:
                return {self._check_sub: [i for i in pattern]}
        else:
            raise AttributeError('Given search pattern could not be decode %s' % pattern)

    def _op_logic(self,pre_result,result):
        '''
        depending if "or" or "and" combine is set this method
        checks the logical combination and gives back if we should stop or not
        :param pre_result: last result
        :param result: result
        :return: stop (True/False), new result
        '''
        if self._op:
            if result or pre_result:
                return True,True
            else:
                return False,False
        else:
            if result and pre_result:
                return False, True
            else:
                return True, False

    def _check_tag_eq(self,item, item_filter=None, patterns=None):
        if patterns is None:
            return False
        tag = item._tag
        result=not self._op
        for pattern in patterns:
            if pattern=='*':
                #any match
                stop, result = self._op_logic(result, True)
            else:
                stop,result=self._op_logic(result,(tag==pattern))
            if stop:
                return result
        return result

    def _check_tag_str(self, item, item_filter=None, patterns=None):
        if patterns is None:
            return False
        tag = item._tag
        result=not self._op
        check=fnmatch.fnmatch
        for pattern in patterns:
            stop, result = self._op_logic(result, check(tag, pattern))
            if stop:
                return result
        return result

    def _check_idxs(self, item, item_filter=None, patterns=None):
        if patterns is None:
            return False
        if item.parent is None:
            return False
        if self._op:
            return item.parent.index(item, item_filter) in patterns
        else:
            idx = item.parent.index(item, item_filter)
            for pattern in patterns:
                if idx != pattern:
                    return False
            return True

    def _check_sub(self, item, item_filter=None, patterns=None):
        if patterns is None:
            return False
        result = not self._op
        for pattern in patterns:
            stop, result = self._op_logic(result, iTMatch(pattern).check(item, item_filter))
            if stop:
                return result
        return result

    def check(self, item, item_filter=ALL):
        if type(item_filter) is int:
            i=item_filter
            item_filter=lambda item: ((item._flags & ~i) == 0)
        result=not self._op
        for check_method, patterns in self._check.items():
            stop, result = self._op_logic(result, check_method(item, item_filter, patterns))
            if stop:
                return result
        return result

    def __repr__(self):
        return 'iTreeMatch(pattern=%s, op=%s)' % (repr(self._pattern), repr(self._op))


class TagIdx():

    def __init__(self, tag, idx=None, tag_separator='#'):
        '''
        This is a special tuple containing a combination of tag,index used for the identification
        of elements in iTrees

        HINT: The object can be instanced by giving a tag and and index as parameters. But string only
        parameters will be parsed and split by the separator given e.g. "mytag#1" -> ("mytag",1)
        Obviously parsed tags can only be used if tags used in iTree are string objects!

        The content of the object can be reached via property obj.tag, obj.idx or per index obj[0](tag), obj[1] (index).

        :param tag: tag object (string or hashable object)
        :param idx: for single target integer object (or None for parsed tags)
                    for multi target None (pure tag without index -> tag_family target)
                                     slice
                                     index list/iterator
        :param tag_separator: separator for split of tag and index (default is "#")
        '''
        if idx is None:
            tag, idx = tag.split(tag_separator)
            if ':' in idx:
                tmp=idx.split(':')
                slice_parameter=[int(i) for i in tmp]
                idx=slice(*slice_parameter)
            else:
                idx=int(idx)
        self._tuple = (tag, idx)
        self._is_single=(type(self.idx) is int)
    @property
    def is_TagIdx(self):
        return True

    @property
    def tag(self):
        return self._tuple[0]

    @property
    def idx(self):
        return self._tuple[1]

    @property
    def is_single(self):
        return self._is_single

    def __getitem__(self, idx):
        return self._tuple[idx]

    def __hash__(self):
        return hash(self._tuple)

    def __repr__(self):
        return 'TagIdx(%s, %s)'%(repr(self.tag),repr(self.idx))

